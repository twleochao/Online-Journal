This is assignment 3 for my ICS32 class.
